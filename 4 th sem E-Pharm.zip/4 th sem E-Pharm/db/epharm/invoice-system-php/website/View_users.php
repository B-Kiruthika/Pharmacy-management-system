
<html>  
<head lang="en">  
    <meta charset="UTF-8">  
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous"> 
<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    
    
    <link type="text/css" rel="stylesheet" href="bootstrap-3.2.0-dist\css\bootstrap.css"> <!--css file link in bootstrap folder-->  
    <title>Admin Dashboard Page</title>  
</head>  
<style>  
    .login-panel {  
        margin-top: 150px;  
    }  
    .table {  
        margin-top: 50px;  
     }  
	 .header{
		 color:red;
		 text-align: center;
	 }
	 body{
		border-top: 8px double red;
			border-right: 8px solid red;
			border-left: 8px solid red;
			border-bottom: 10px double red;
			border-radius: 30px;
            
	 }
	
</style>  
  
<body style="background-color:rgba(164, 175, 0, 0.3);">  

	
	
  

</body>  


<br>
<br>
<?php
$conn=new PDO('mysql:host=localhost; dbname=users', 'root', '') or die(mysql_error());
if(isset($_POST['submit'])!=""){
  $name=$_FILES['file']['name'];
  $size=$_FILES['file']['size'];
  $type=$_FILES['file']['type'];
  $temp=$_FILES['file']['tmp_name'];

  $file_name=$_POST["filename"];
  // $caption1=$_POST['caption'];
  // $link=$_POST['link'];
  $fname = date("YmdHis").'_'.$name;
  $chk = $conn->query("SELECT * FROM  upload where name = '$name' ")->rowCount();
  if($chk){
    $i = 1;
    $c = 0;
	while($c == 0){
    	$i++;
    	$reversedParts = explode('.', strrev($name), 2);
    	$tname = (strrev($reversedParts[1]))."_".($i).'.'.(strrev($reversedParts[0]));
    // var_dump($tname);exit;
    	$chk2 = $conn->query("SELECT * FROM  upload where name = '$tname' ")->rowCount();
    	if($chk2 == 0){
    		$c = 1;
    		$name = $tname;
    	}
    }
}
 $move =  move_uploaded_file($temp,"upload/".$fname);
 if($move){
 	$query=$conn->query("insert into upload(name,fname,file_name)values('$name','$fname','$file_name')");
	if($query){
	header("location:view_users.php");
	}
	else{
	die(mysql_error());
	}
 }
}
?>
<html>
<head>
<title>Upload and Download Files</title>
		<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
        <link rel="stylesheet" type="text/css" href="css/DT_bootstrap.css">
</head>
	<script src="js/jquery.js" type="text/javascript"></script>
	<script src="js/bootstrap.js" type="text/javascript"></script>
	
	<script type="text/javascript" charset="utf-8" language="javascript" src="js/jquery.dataTables.js"></script>
	<script type="text/javascript" charset="utf-8" language="javascript" src="js/DT_bootstrap.js"></script>

<style>
</style>
<body>
	    <div class="row-fluid">
	        <div class="span12">
	            <div class="container">
	
		
		<h4 style="font-family:Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif; font-size: 30px; color:rgb(34, 206, 85)" align="center"> prescription Upload File </h4> 
		<br />
		<br />
			<form enctype="multipart/form-data" action="" name="form" method="post">
				<span style="font-size: 20px;">Select File</span>
					<input type="file" name="file" id="file" /></td>
					<input style="height: 30px;" type="text" placeholder="Enter your id" id="filename" name="filename">
					
					<button style="background-color: rgb(180, 89, 89); color:white; padding:5px; border:1px solid rgb(175, 84, 84);" type="submit" name="submit" id="submit" value="Submit" >Submit</button>
			</form>
		<br />
		<br />
		<table cellpadding="0" cellspacing="0" border="1" class="table table-striped table-bordered" id="example">
			<thead>
				<tr>
					<th  align="center">Files Name</th>
					<th width="60%" align="center">Files </th>
					<th width="30%" align="center">File Name</th>
						
				
					<th align="center">Action</th>	
					  <th>Delete file</th>  
					
				</tr>
			</thead>
			
			<?php
			$query=$conn->query("select * from upload order by id desc");
			while($row=$query->fetch()){
				$id=$row['id'];
				$name=$row['name'];
				$file_name=$row['file_name'];
				$time=$row['current_time'];

			?>
			<tr>
			<td>&nbsp;<?php echo $file_name ;?>
			
				<td>
					&nbsp;<?php echo $name ;?>
				</td>
				
				

				</td>
				<td>&nbsp;<?php echo $time ;?></td>
				<td>
					<button class="alert-success"><a href="download.php?filename=<?php echo $name;?>&f=<?php echo $row['fname'] ?>">Download</a></button>
				</td>
			
				<td><a href="delete_file.php?del=<?php echo $id ?>"><button class="btn btn-danger">Delete</button></a></td> <!--btn btn-danger is a bootstrap button to show danger-->  
				
			</tr>
			<?php }?>
		</table>
	</div>
	</div>
	</div>
</body>
</html>
  
</html>