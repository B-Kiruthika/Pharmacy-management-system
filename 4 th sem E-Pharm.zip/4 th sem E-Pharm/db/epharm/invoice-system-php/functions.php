<?php
// include_once("config.php");
function popProductsList() {

// Connect to the database
$mysqli = new mysqli("localhost","root","","mysite");

// output any connection error
if ($mysqli->connect_error) {
    die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
}

// the query
$query = "SELECT * FROM search ORDER BY name ASC";

// mysqli select query
$results = $mysqli->query($query);

if($results) {
    echo '<select class="form-control item-select">';
    while($row = $results->fetch_assoc()) {

        // print '<option value="'.$row['product_price'].'">'.$row["product_name"].' - '.$row["product_desc"].'</option>';
            print '<option value="'.$row['product_price'].'">'.$row["name"].'</option>';
    }
    echo '</select>';

} else {

    echo "<p>There are no products, please add a product.</p>";

}

// Frees the memory associated with a result
$results->free();

// close connection 
$mysqli->close();

}

?>
