<?php 
$id5=$_POST['orderid'];
$id4=$_POST['itemid'];
$id=$_POST['productname'];
$id1=$_POST['productname1'];
$id2=$_POST['productname2'];
$id3=$_POST['amount'];

// $first_name=$_POST['name1'];
// $last_name=$_POST['name2'];
// $regno=$_POST['rno'];
// $dept=$_POST['dpt'];

// $year=$_POST['yer'];
// $dateofbirth=$_POST['dof'];
// $emailid=$_POST['em'];
// $phoneno=$_POST['ph'];
// $gender=$_POST['g'];
// $address=$_POST['a'];




$host = "localhost";
$username = "root";
$password = "";
$dbname = "simpleinvoicephp";


$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO invoice_order_item (order_id,item_code,item_name,order_item_quantity,order_item_price,order_item_final_amount)
VALUES ('$id5','$id4','$id','$id1','$id2','$id3')";

if ($conn->query($sql) === TRUE) {
  
  echo" <script> window.alert('Data has been securly stored') </script> ";
//   header('Location: http://localhost/poovithaproject/login.html');
  echo"data stored";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>