<?php

include('header.php');
include('functions.php');

?>

	

			<script>
                function total(){
                    var a=document.getElementById('in1').value;
                    var b=document.getElementById('in2').value;
                    let c=parseInt(a)*parseInt(b);
                    document.getElementById("amount").value=c;
                }
            </script>
			
			<form action="store.php" method="post">
                <table class="table table-bordered table-hover table-striped" id="invoice_table">
				
					<tr>
						<td>
							<!-- order no -->
							<input type="text" placeholder="Ener your order id" name="orderid">
						</td>
						<td>
							<!-- item no -->
							<input type="text" placeholder="Ener your item id" name="itemid">
						</td>
						<td>
						<!-- name -->
								<input type="text" class="form-control form-group-sm item-input invoice_product" name="productname" name="invoice_product[]" placeholder="Enter Product Name OR Description">
								<p class="item-select">or <a href="#">select a product</a></p>
                               
						
						</td>
						<td class="text-right">
							<!-- quntity -->
						
								<input type="number" class="form-control invoice_product_qty calculate" name="productname1" id="in1" name="invoice_product_qty[]" value="1">
							
						</td>
						<td class="text-right">
							<div class="input-group input-group-sm  no-margin-bottom">
							<!-- price -->
								<input type="number" class="form-control calculate invoice_product_price required" id="in2" name="productname2" name="invoice_product_price[]" aria-describedby="sizing-addon1" placeholder="0.00">
							</div>
						</td>
						<!-- <td class="text-right">
							<div class="form-group form-group-sm  no-margin-bottom">
								<input type="text" class="form-control calculate" name="productname3" name="invoice_product_discount[]" placeholder="Enter % OR value (ex: 10% or 10.50)">
							</div>
						</td>
						<td class="text-right">
							<div class="input-group input-group-sm">
								<span class="input-group-addon"><?php echo CURRENCY ?></span>
								<input type="text" class="form-control calculate-sub" name="productname4" name="invoice_product_sub[]" id="invoice_product_sub" value="0.00" aria-describedby="sizing-addon1" disabled>
                               
							</div>
						</td> -->
                        <td>
							<!-- total -->
                            <input type="number" name="amount" id="amount">
                            
                        </td>
                        <td>
                            <button onclick="total()">Calculate Prize</button>
                        </td>
                        <td>
                            <input type="submit">
                        </td>
                        
					</tr>
				</tbody>
			</table>
            </form>

			<br>
			<br>
			<hr>
			<br>
			<form action="store1.php" method="post">
				<input type="number" name="orderid" placeholder="Orderid">
				<input type="text" name="to" placeholder="Reciver name">
				<input type="text" name="address" placeholder="Reciver address">
				<input type="text" name="notes" placeholder="Notes">
				<input type="text" name="totalamount" placeholder="Total amount">
				<input type="submit">
			</form>

            <!-- <button onclick="total()">TOtal</button> -->
           
		
		

		<div id="insert" class="modal fade">
		  <div class="modal-dialog">
		    <div class="modal-content">
		      <div class="modal-header">
		        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		        <h4 class="modal-title">Select Product</h4>
		      </div>
		      <div class="modal-body">
				<?php popProductsList(); ?>
		      </div>
		      <div class="modal-footer">
		        <button type="button" data-dismiss="modal" class="btn btn-primary" id="selected">Add</button>
				<button type="button" data-dismiss="modal" class="btn">Cancel</button>
		      </div>
		    </div><!-- /.modal-content -->
		  </div><!-- /.modal-dialog -->
		</div><!-- /.modal -->


      

	