<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Animated Login Page | Webdevtrick.com</title>
  <link href="https://fonts.googleapis.com/css?family=Rubik&display=swap" rel="stylesheet">
<link rel="stylesheet" href="login1.css">
</head>
<body>
 
<div class="container">
<div class="container">
  <hgroup>
    <h1 class="site-title" style="text-align: center; color: green;"></h1><br>
  </hgroup>

  <div class="left-section">
    <div class="header">  <h1 class="animation a1">Consumer login</h1>
      <h4 class="animation a2"></h4>
    </div>
    <div class="form">
    <form method="post" action="login.php">
      <input type="email" name="username" class="form-field animation a3" placeholder="Username">
      <input type="password" name="password" class="form-field animation a4" placeholder="Password">
      <p class="animation a5"><a href="http://localhost/epharm/home.php">Forgot Password</a></p>
      <button class="animation a6">   <input type="submit" name="login_btn" class="Log In"></button>
      <button> <a href="home.php">Register</a></button>
   
</form>
 
    </div>
  </div>
  <!-- <div class="right-section"></div> -->
</div>
  
</body>
</html>