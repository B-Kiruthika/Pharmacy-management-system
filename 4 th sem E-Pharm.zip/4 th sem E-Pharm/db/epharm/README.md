# Login-Registration-Logout-System-with-PHP-Mysql


used PHP Mysql

Database name mysite.
   1 table name: users
   CREATE TABLE `users` (
  `userid` int(11) NOT NULL,
  `username` varchar(150) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
  )

       
